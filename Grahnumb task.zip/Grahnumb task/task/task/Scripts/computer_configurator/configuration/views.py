from django.shortcuts import render

# Create your views here.


from django.core.mail import send_mail
from django.shortcuts import render, redirect
from .forms import ConfigurationForm


def configure_computer(request):
    
    return render(request, 'configuration/configure_computer.html')

def configure_computer(request):
    if request.method == 'POST':
        form = ConfigurationForm(request.POST)
        if form.is_valid():
            configuration = form.save()
            send_email(configuration)
            return redirect('success_page') 
    else:
        form = ConfigurationForm()
    return render(request, 'configuration/configure_computer.html', {'form': form})

def send_email(configuration):
    
    subject = 'New Computer Configuration'
    message = f"CPU: {configuration.cpu}\nRAM: {configuration.ram}\nHard Disk: {configuration.hard_disk}\nAddress: {configuration.address}"
    from_email = 'smtp.gmail.com'
    recipient_list = ['vendor@email.com']
    send_mail(subject, message, from_email, recipient_list)


def success_page(request):
    return render(request, 'success_page.html')

