from django.db import models

# Create your models here.

class Configuration(models.Model):
    cpu = models.CharField(max_length=50)
    ram = models.CharField(max_length=50)
    hard_disk = models.CharField(max_length=50)
    address = models.TextField()

    def __str__(self):
        return f"{self.cpu}, {self.ram}, {self.hard_disk}"